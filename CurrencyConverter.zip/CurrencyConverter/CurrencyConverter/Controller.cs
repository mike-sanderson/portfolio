﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Xml.Linq;

namespace CurrencyConverter
{
    public class Controller
    {
        private Dictionary<string, double> _conversionTable;

        public Controller()
        {
            XDocument doc = XDocument.Load("https://www.ecb.europa.eu/stats/eurofxref/eurofxref-daily.xml");
            _conversionTable = new Dictionary<string, double>();
            
            // Had a bit of trouble with the direct LINQ ToDictionary function as the xml has multiple nested "Cube" tags, so I did it the verbose way
            foreach(XElement element in doc.Descendants().Where(e => !e.HasElements && e.HasAttributes))
            {
                string currency = element.Attribute("currency").Value;
                double rate = double.Parse(element.Attribute("rate").Value);
                _conversionTable.Add(currency, rate);
            }
        }

        public double DoConversion(string to, double initial)
        {
            double rate = double.NaN;
            bool ratePulled = _conversionTable.TryGetValue(to, out rate);
            if(ratePulled)
            {
                return initial * rate;
            }
            return rate;
        }

        public ICollection GetCurrencies()
        {
            return _conversionTable.Keys;
        }
    }
}
