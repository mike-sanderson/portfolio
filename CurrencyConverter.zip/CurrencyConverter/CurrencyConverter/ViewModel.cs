﻿using Microsoft.Expression.Interactivity.Core;
using System.ComponentModel;
using System.Windows.Data;
using System.Windows.Input;

namespace CurrencyConverter
{
    public class ViewModel : INotifyPropertyChanged
    {
        private ICommand conversionCommand;
        private Controller _controller;
        private readonly CollectionView _currencies;
        private string _denomination;
        private string _toConvert;
        private string _converted;
        
        public ViewModel()
        {
            _controller = new Controller();
            _currencies = new CollectionView(_controller.GetCurrencies());
            conversionCommand = new ActionCommand(Conversion);
        }

        public ICommand ConversionCommand
        {
            get { return conversionCommand; }
        }

        public CollectionView Currencies
        {
            get { return _currencies; }
        }

        public string ToConvert
        {
            get { return _toConvert; }
            set
            {
                if (_toConvert == value)
                    return;
                _toConvert = value;
                OnPropertyChanged("ToConvert");
            }
        }

        public string Converted
        {
            get { return _converted; }
            set
            {
                if (_converted == value)
                    return;
                _converted = value;
                OnPropertyChanged("Converted");
            }
        }

        public string Denomination
        {
            get { return _denomination; }
            set
            {
                if (_denomination == value)
                    return;
                _denomination = value;
                OnPropertyChanged("Denomination");
            }
        }

        private void Conversion()
        {
            double input = double.NaN;
            bool isNumber = double.TryParse(ToConvert, out input);
            if (string.IsNullOrEmpty(Denomination))
                Converted = "Select a currency!";
            else if (!isNumber)
                Converted = "Input not a number!";
            else
            {
                double result = _controller.DoConversion(Denomination, input);
                if (!double.IsNaN(result))
                    Converted = result.ToString("0.##");
                else
                    Converted = "Conversion error!";
            }
        }

        private void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
        public event PropertyChangedEventHandler PropertyChanged;
    }
}
