package edu.bc.cs.sandermg.cs344s14.hw5_getlost;

import java.text.DecimalFormat;
import java.util.Locale;

import android.app.ActionBar;
import android.app.FragmentTransaction;
import android.graphics.Matrix;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentActivity;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ImageView.ScaleType;
import android.widget.TextView;

public class MainActivity extends FragmentActivity implements
		ActionBar.TabListener {

	/**
	 * The {@link android.support.v4.view.PagerAdapter} that will provide
	 * fragments for each of the sections. We use a
	 * {@link android.support.v4.app.FragmentPagerAdapter} derivative, which
	 * will keep every loaded fragment in memory. If this becomes too memory
	 * intensive, it may be best to switch to a
	 * {@link android.support.v4.app.FragmentStatePagerAdapter}.
	 */
	SectionsPagerAdapter mSectionsPagerAdapter;
	private LocationListener listener;
	private LocationManager locManager;
	private Compass compass;

	/**
	 * The {@link ViewPager} that will host the section contents.
	 */
	ViewPager mViewPager;
	private double markedLatitude, markedLongitude, currentLongitude, currentLatitude, distance, bearing = Double.NaN;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		// Set up the action bar.
		final ActionBar actionBar = getActionBar();
		actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);

		// Create the adapter that will return a fragment for each of the two
		// primary sections of the app.
		mSectionsPagerAdapter = new SectionsPagerAdapter(
				getSupportFragmentManager());

		// Set up the ViewPager with the sections adapter.
		mViewPager = (ViewPager) findViewById(R.id.pager);
		mViewPager.setAdapter(mSectionsPagerAdapter);
		
		// When swiping between different sections, select the corresponding
		// tab. We can also use ActionBar.Tab#select() to do this if we have
		// a reference to the Tab.
		mViewPager
				.setOnPageChangeListener(new ViewPager.SimpleOnPageChangeListener() {
					@Override
					public void onPageSelected(int position) {
						actionBar.setSelectedNavigationItem(position);
					}
				});

		// For each of the sections in the app, add a tab to the action bar.
		for (int i = 0; i < mSectionsPagerAdapter.getCount(); i++) {
			// Create a tab with text corresponding to the page title defined by
			// the adapter. Also specify this Activity object, which implements
			// the TabListener interface, as the callback (listener) for when
			// this tab is selected.
			actionBar.addTab(actionBar.newTab()
					.setText(mSectionsPagerAdapter.getPageTitle(i))
					.setTabListener(this));
		}
		
		compass = new Compass(this);
		locManager = (LocationManager)getSystemService(LOCATION_SERVICE);
		
		setupGPSWatcher();
	}
	
	public void markLocation(View view)
	{
		DecimalFormat tenThousandths = new DecimalFormat("#.0000");
		markedLatitude = currentLatitude;
		markedLongitude = currentLongitude;
		((TextView)findViewById(R.id.markedLatitude)).setText(""+tenThousandths.format(markedLatitude));
		((TextView)findViewById(R.id.markedLongitude)).setText(""+tenThousandths.format(markedLongitude));
	}
	
	private void setBearingAndDirection(double lat1, double lon1, double lat2, double lon2) {
		// formulas from http://www.ig.utexas.edu/outreach/googleearth/latlong.html
		double earthRadius = 3963; // miles
		double dLat = lat2 - lat1;
		double dLon = lon2 - lon1;
		double sdLat = Math.sin(Math.toRadians(dLat/2));
		double sdLon = Math.sin(Math.toRadians(dLon/2));
		double a = sdLat*sdLat + Math.cos(Math.toRadians(lat1))*Math.cos(Math.toRadians(lat2))*sdLon*sdLon;
		double c = 2*Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
		distance = earthRadius * c; // miles
		bearing  = Math.toDegrees(Math.atan2(Math.sin(Math.toRadians(dLon))*Math.cos(Math.toRadians(lat2)), 
				Math.cos(Math.toRadians(lat1))*Math.sin(Math.toRadians(lat2))-
				Math.sin(Math.toRadians(lat1))*Math.cos(Math.toRadians(lat2))*Math.cos(Math.toRadians(dLon))));
		rotateImage();
	}
	
	private void rotateImage()
	{
		ImageView arrow = (ImageView)findViewById(R.id.arrowImage); // initially points up
		if (arrow != null) {
			Matrix matrix=new Matrix();
			arrow.setScaleType(ScaleType.MATRIX);   //required
			int cx = arrow.getWidth()/2;
			int cy = arrow.getHeight()/2;
			float azimuth = Double.isNaN(compass.getAzimuth()) ? 0f : compass.getAzimuth();
			matrix.postRotate(-azimuth, cx, cy); // toward north
			matrix.postRotate((float)bearing, cx, cy); // toward mark, should be no minus
			arrow.setImageMatrix(matrix);
		}
	}
	
	private void sendTextToScreen()
	{
		DecimalFormat hundredths = new DecimalFormat("#.00");
		DecimalFormat tenThousandths = new DecimalFormat("#.0000");
		try {
			switch (mViewPager.getCurrentItem()) {
			case 0:
				((TextView)findViewById(R.id.currentLatitude1)).setText(""+tenThousandths.format(currentLatitude));  // notice that we're on the UI thread, "post" not needed
				((TextView)findViewById(R.id.currentLongitude1)).setText(""+tenThousandths.format(currentLongitude));
				break;
			case 1:
				((TextView)findViewById(R.id.currentLatitude2)).setText(""+tenThousandths.format(currentLatitude));  // notice that we're on the UI thread, "post" not needed
				((TextView)findViewById(R.id.currentLongitude2)).setText(""+tenThousandths.format(currentLongitude));
				if(!(markedLatitude == Double.NaN || markedLongitude == Double.NaN))
				{
					setBearingAndDirection(currentLatitude, currentLongitude, markedLatitude, markedLongitude);
					((TextView)findViewById(R.id.distance)).setText(hundredths.format(distance) + " miles");
					((TextView)findViewById(R.id.bearing)).setText((int)(bearing<0 ? bearing+360 : bearing) + " degrees");
				}
				break;
			}
		} catch (NullPointerException e) {
			// TODO Auto-generated catch block
			Log.e("FindMyLocation", e.toString());
		}
	}
	
	private void setupGPSWatcher() {
		listener = new LocationListener() {
			@Override
			public void onLocationChanged(Location location) {
				if (location != null) {
					currentLatitude  = location.getLatitude();
					currentLongitude = location.getLongitude();
					Log.d("FindMyLocation", ""+currentLatitude);
					Log.d("FindMyLocation", ""+currentLongitude);
					
					sendTextToScreen();
				} else {
					//statusField.setText(R.string.locationUnknown);
					Log.d("FindMyLocation", "Location changed to null!!");
				}
			}

			@Override
			public void onProviderDisabled(String provider) {
				Log.d("FindMyLocation", provider + " disabled");
//				statusField.setText(R.string.providerDisabled);
			}

			@Override
			public void onProviderEnabled(String provider) {
				Log.d("FindMyLocation", provider + " enabled");
//				statusField.setText(R.string.providerEnabled);
			}

			@Override
			public void onStatusChanged(String provider, int status, Bundle extras) {
				Log.d("FindMyLocation", provider + " changed, see status/extras");
//				switch (status) {
//					case LocationProvider.OUT_OF_SERVICE:          statusField.setText(R.string.outOfService); break;
//					case LocationProvider.AVAILABLE:               statusField.setText(R.string.available);    break;
//					case LocationProvider.TEMPORARILY_UNAVAILABLE: statusField.setText(R.string.tempUnavail);  break;
//				}
			}
		};
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

	@Override
	public void onTabSelected(ActionBar.Tab tab,
			FragmentTransaction fragmentTransaction) {
		// When the given tab is selected, switch to the corresponding page in
		// the ViewPager.
		mViewPager.setCurrentItem(tab.getPosition());
		sendTextToScreen();
	}

	@Override
	public void onTabUnselected(ActionBar.Tab tab,
			FragmentTransaction fragmentTransaction) {
	}

	@Override
	public void onTabReselected(ActionBar.Tab tab,
			FragmentTransaction fragmentTransaction) {
	}
	
	@Override
	public void onResume() {
		super.onResume();
		locManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000 /* milliseconds */, 1 /* meters */, listener);
		Log.i("FindMyLocation", "Location listening on");
	}
	
	@Override
	public void onPause() { // Don't use CPU time or battery when paused!
		super.onPause();
		locManager.removeUpdates(listener);
		Log.i("FindMyLocation", "Location listening off");
	}

	/**
	 * A {@link FragmentPagerAdapter} that returns a fragment corresponding to
	 * one of the sections/tabs/pages.
	 */
	public class SectionsPagerAdapter extends FragmentPagerAdapter {

		public SectionsPagerAdapter(FragmentManager fm) {
			super(fm);
		}

		@Override
		public Fragment getItem(int position) {
			Log.i("Swipe", "*****getItem " + position);
			switch(position) {
			case 0: return new SectionFragment1();
			case 1: return new SectionFragment2();
			}
			return null; // shouldn't happen
		}

		@Override
		public int getCount() {
			// Show 2 total pages.
			return 2;
		}

		@Override
		public CharSequence getPageTitle(int position) {
			Locale l = Locale.getDefault();
			switch (position) {
			case 0:
				return getString(R.string.title_section1).toUpperCase(l);
			case 1:
				return getString(R.string.title_section2).toUpperCase(l);
			}
			return null;
		}
	}

}

class SectionFragment1 extends Fragment {

	public SectionFragment1() {
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.fragment1,
				container, false);
		return rootView;
	}
}
class SectionFragment2 extends Fragment {

	public SectionFragment2() {
	}

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.fragment2,
				container, false);
		return rootView;
	}
}
