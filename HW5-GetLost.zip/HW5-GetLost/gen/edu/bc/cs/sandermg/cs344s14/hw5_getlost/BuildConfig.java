/** Automatically generated file. DO NOT MODIFY */
package edu.bc.cs.sandermg.cs344s14.hw5_getlost;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}